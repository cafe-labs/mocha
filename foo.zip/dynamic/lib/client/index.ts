import Client from './client';

export default Client(self) as Window;