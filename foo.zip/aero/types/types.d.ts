declare global {
    var $aero: any
    var $location: any
}

export {};