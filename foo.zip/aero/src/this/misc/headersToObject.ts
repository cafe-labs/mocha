// @ts-ignore
export default (headers: Headers) => Object.fromEntries(headers.entries());
