import { proxyString } from "./autoProxy";

proxyString(BroadcastChannel);
