const proxyLocation = {};

self.location = proxyLocation;
