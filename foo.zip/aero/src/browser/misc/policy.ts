// TODO: Check the policy of the parent's too in case this is an iframe
export default list => {
	if (list) {
	}

	return false;
};
