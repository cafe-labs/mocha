import { proxyGetString } from "shared/autoProxy/autoProxy";

proxyGetString("PushSubscription", ["endpoint"]);
