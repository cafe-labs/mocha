import { proxyConstructString } from "shared/autoProxy/autoProxy";

proxyConstructString("EventSource", [1]);
