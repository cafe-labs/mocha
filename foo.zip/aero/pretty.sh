# TODO: Put this inside of package.json
npx prettier --write .