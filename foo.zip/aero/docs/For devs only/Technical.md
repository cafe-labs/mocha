# Technical

## Foreword
This is the best read for those who want to become contributors
Make sure you understand the Technical Concepts before coming here