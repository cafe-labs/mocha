TODO: Explain what this file is for, then finish this

# Message Channel Documentation for implementors of a proxy browser

**BROWSER_GET_ENGINE** -
