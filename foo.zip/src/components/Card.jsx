function Card(props) {
    return (
        <>
            {props.children}
        </>
    )
}

export default Card;